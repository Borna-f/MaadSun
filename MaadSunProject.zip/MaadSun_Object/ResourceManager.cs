﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaadSun_Object
{
    public enum RoleUser { Admin = 100, User=80};
    
    public class ResourceManager
    {
        public static string XMLFilePath = "F:\\MaadSun\\XMLFiles\\";
        public static string ImagePath = "/Uploads/";
    }
}
